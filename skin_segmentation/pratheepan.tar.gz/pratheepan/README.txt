dataset downloaded from:
http://web.fsktm.um.edu.my/~cschan/downloads_skin_dataset.html


Details
-------

The images in this dataset are downloaded randomly from Google for human skin detection research. These images are captured with a range of different cameras using different colour enhancement and under different illuminations.

Note: We would like to thank - Mr. Mohd Zamri, currently a PhD student from University Technology Malaysia (UTM) for his effort in preparing the groundtruth of this dataset.

There are four(4) folders associated with the dataset:

    FacePhoto -
        Single subject
        Simple background
        Total Images = 32
    FamilyPhoto -
        Multiple subjects
        Complex background
        Total Images = 46
    GroundT_FacePhoto -
        The groundtruth images for FacePhoto
    GroundT_FamilyPhoto -
        The groundtruth images for FamilyPhoto
